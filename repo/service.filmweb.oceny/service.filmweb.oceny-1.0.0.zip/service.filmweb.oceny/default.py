# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import json
import urllib
import re
import os

__addon__               = xbmcaddon.Addon()
__addon_id__            = __addon__.getAddonInfo('id')
__addonname__           = __addon__.getAddonInfo('name')
__icon__                = __addon__.getAddonInfo('icon')
__addonpath__           = xbmc.translatePath(__addon__.getAddonInfo('path'))

#name of script for this service work
serviceForScript = 'script.filmweb.oceny'

class Player(xbmc.Player):

    def __init__(self):
        xbmc.Player.__init__(self)

    def onPlayBackStarted(self):
    
        ret = self.searchID()
        if len(ret) > 0:
            self.filmwebID = ret[0]
        
    def searchID(self):
    
        jsonGet = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "params": {"playerid": 1}, "method": "Player.GetItem", "id": 1}')
        jsonGet = unicode(jsonGet, 'utf-8', errors='ignore')
        jsonGetResponse = json.loads(jsonGet)
        print jsonGetResponse
        print 'ID: ' + str(jsonGetResponse['result']['item']['id'])
        movieid = str(jsonGetResponse['result']['item']['id'])
        
        jsonGet = xbmc.executeJSONRPC('{"jsonrpc": "2.0", "method": "VideoLibrary.GetMovieDetails", "params": {"movieid": ' + movieid + ', "properties": ["file", "thumbnail", "fanart", "trailer"]}, "id": 1}')
        jsonGet = unicode(jsonGet, 'utf-8', errors='ignore')
        jsonGetResponse = json.loads(jsonGet)
        
        print urllib.unquote(str(jsonGetResponse))
        
        result = re.findall('fwcdn.pl/po/[^/]+/[^/]+/([0-9]+)/', urllib.unquote(str(jsonGetResponse)))
        if len(result) > 0:
            return result
                
        result = re.findall('fwcdn.pl/ph/[^/]+/[^/]+/([0-9]+)/', urllib.unquote(str(jsonGetResponse)))
        if len(result) > 0:
            return result
                
        result = re.findall('http://mm.filmweb.pl/([0-9]+)/', urllib.unquote(str(jsonGetResponse)))
        if len(result) > 0:
            return result
                
        filePath, fileExt = os.path.splitext(jsonGetResponse['result']['moviedetails']['file'])
        fileNfo = filePath + '.nfo'
        
        if os.path.isfile(fileNfo):
        
            file = open(fileNfo, 'r')
            file_data = file.read()
            file.close()
            
            result = re.findall('fwcdn.pl/po/[^/]+/[^/]+/([0-9]+)/', file_data)
            if len(result) > 0:
                return result
            
            result = re.findall('fwcdn.pl/ph/[^/]+/[^/]+/([0-9]+)/', file_data)
            if len(result) > 0:
                return result
                
            result = re.findall('<trailer>http://mm.filmweb.pl/([0-9]+)/', file_data)
            if len(result) > 0:
                return result
                
            result = re.findall('http://www.filmweb.pl/Film?id=([0-9]+)', file_data)
            if len(result) > 0:
                return result
        
    def onPlayBackStopped(self):
    
        if len(self.filmwebID) > 0:
            xbmc.executebuiltin('XBMC.RunScript(' + serviceForScript + ', ' + self.filmwebID + ')')
        
player = Player()

while(not xbmc.abortRequested):
    xbmc.sleep(100)
    