# -*- coding: utf-8 -*-

# THIS ADDON IS DEPRECATED 
    
# UNISTALL IT